import { gql } from '@apollo/client';

export const PUBLIC_MENU_QUERY = gql`
  query PublicMenu($restaurantSlug: String!, $tableId: String) {
    publicMenu(restaurantSlug: $restaurantSlug, tableId: $tableId) {
      restaurant {
        id
        name
        logo
        brandColor
        currency
      }
      table {
        id
        tableNumber
        name
      }
      categories {
        id
        name
        items {
          id
          name
          description
          price
          image
          availability
        }
      }
    }
  }
`;

export const CREATE_GUEST_ORDER_MUTATION = gql`
  mutation CreateGuestOrder($input: CreateGuestOrderInput!) {
    createGuestOrder(input: $input) {
      orderId
      orderNumber
      total
    }
  }
`;

export const TRACK_ORDER_QUERY = gql`
  query TrackGuestOrder($restaurantSlug: String!, $orderNumber: String!, $guestPhone: String!) {
    trackGuestOrder(restaurantSlug: $restaurantSlug, orderNumber: $orderNumber, guestPhone: $guestPhone) {
      orderNumber
      status
      type
      total
      tableNumber
      createdAt
      items {
        name
        quantity
      }
      history {
        status
        changedAt
      }
      delivery {
        status
        deliveryAddress
        partnerName
        partnerPhone
      }
    }
  }
`;