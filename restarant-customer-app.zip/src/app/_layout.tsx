import '../global.css';
import { Stack } from 'expo-router';
import { ApolloProvider } from '@apollo/client/react';
import { client } from '../lib/apollo';
import { CartProvider } from '../context/CartContext';

export default function RootLayout() {
  return (
    <ApolloProvider client={client}>
      <CartProvider>
        <Stack screenOptions={{ headerShown: true }} />
      </CartProvider>
    </ApolloProvider>
  );
}