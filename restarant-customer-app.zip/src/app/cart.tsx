import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const router = useRouter();
  const { items, updateQuantity, total } = useCart();

  if (items.length === 0) {
    return (
      <View className="flex-1 items-center justify-center p-6">
        <Text className="text-gray-500">Your cart is empty.</Text>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-white">
      <FlatList
        data={items}
        keyExtractor={(l) => l.menuItemId}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item: line }) => (
          <View className="flex-row items-center border-b border-gray-100 py-3">
            <View className="flex-1">
              <Text className="text-[15px] font-semibold">{line.name}</Text>
              <Text className="mt-0.5 text-[13px] text-gray-500">৳{line.price} each</Text>
            </View>
            <View className="flex-row items-center gap-3">
              <TouchableOpacity
                className="h-8 w-8 items-center justify-center rounded-full bg-gray-100"
                onPress={() => updateQuantity(line.menuItemId, line.quantity - 1)}
              >
                <Text className="text-lg font-bold">−</Text>
              </TouchableOpacity>
              <Text className="w-6 text-center font-semibold">{line.quantity}</Text>
              <TouchableOpacity
                className="h-8 w-8 items-center justify-center rounded-full bg-gray-100"
                onPress={() => updateQuantity(line.menuItemId, line.quantity + 1)}
              >
                <Text className="text-lg font-bold">+</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      <View className="border-t border-gray-100 p-4">
        <View className="mb-3 flex-row justify-between">
          <Text className="text-base font-semibold">Total</Text>
          <Text className="text-base font-bold">৳{total}</Text>
        </View>
        <TouchableOpacity
          className="items-center rounded-xl bg-brand py-3.5"
          onPress={() => router.push('/checkout')}
        >
          <Text className="text-[15px] font-bold text-white">Proceed to checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}