import { View, Text, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useQuery } from '@apollo/client/react';
import { useRouter } from 'expo-router';
import { PUBLIC_MENU_QUERY } from '../lib/graphql';
import { useCart } from '../context/CartContext';
import { RESTAURANT_SLUG } from '../constants';

export default function Menu() {
  const router = useRouter();
  const { tableId, addItem, items } = useCart();

  const { data, loading, error } = useQuery(PUBLIC_MENU_QUERY, {
    variables: { restaurantSlug: RESTAURANT_SLUG, tableId: tableId ?? undefined },
  });

  if (loading) return <ActivityIndicator className="flex-1" />;
  if (error || !data) {
    return (
      <View className="flex-1 items-center justify-center p-6">
        <Text>Could not load the menu. Please try again.</Text>
      </View>
    );
  }

  const cartCount = items.reduce((sum, l) => sum + l.quantity, 0);

  return (
    <View className="flex-1 bg-white">
      {data.publicMenu.table && (
        <View className="items-center bg-amber-100 py-2.5">
          <Text className="font-semibold text-amber-800">Table: {data.publicMenu.table.tableNumber}</Text>
        </View>
      )}

      <FlatList
        data={data.publicMenu.categories}
        keyExtractor={(c) => c.id}
        contentContainerStyle={{ paddingBottom: 100 }}
        renderItem={({ item: category }) => (
          <View className="px-4 pt-4">
            <Text className="mb-2 text-lg font-bold">{category.name}</Text>
            {category.items.map((menuItem: any) => (
              <View key={menuItem.id} className="flex-row items-center border-b border-gray-100 py-2.5">
                <View className="flex-1">
                  <Text className="text-[15px] font-semibold">{menuItem.name}</Text>
                  <Text className="mt-0.5 text-[13px] text-gray-500">
                    {data.publicMenu.restaurant.currency} {menuItem.price}
                  </Text>
                </View>
                <TouchableOpacity
                  disabled={menuItem.availability === 'OUT_OF_STOCK'}
                  className={`rounded-lg bg-ink px-3.5 py-2 ${menuItem.availability === 'OUT_OF_STOCK' ? 'opacity-40' : ''}`}
                  onPress={() =>
                    addItem({ menuItemId: menuItem.id, name: menuItem.name, price: menuItem.price })
                  }
                >
                  <Text className="text-[13px] font-semibold text-white">Add</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        )}
      />

      {cartCount > 0 && (
        <TouchableOpacity
          className="absolute bottom-5 left-4 right-4 items-center rounded-xl bg-brand py-3.5"
          onPress={() => router.push('/cart')}
        >
          <Text className="text-[15px] font-bold text-white">View cart ({cartCount})</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}