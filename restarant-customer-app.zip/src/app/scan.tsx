import { useState } from 'react';
import { View, Text } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';

export default function Scan() {
  const router = useRouter();
  const { setTableId, setOrderType } = useCart();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  if (!permission) return <View />;
  if (!permission.granted) {
    return (
      <View className="flex-1 items-center justify-center gap-3 p-6">
        <Text className="text-center text-gray-600">Camera access is needed to scan the table QR code.</Text>
        <Text onPress={requestPermission} className="font-semibold text-brand">
          Grant permission
        </Text>
      </View>
    );
  }

  function handleScan({ data }: { data: string }) {
    if (scanned) return;
    setScanned(true);
    // QR-এ tableId কীভাবে এনকোড করা আছে সেটা আপনার dashboard-এর QR
    // জেনারেশন লজিকের সাথে মিলিয়ে এই পার্সিং ঠিক করুন
    const tableId = data.includes('table=') ? data.split('table=')[1].split('&')[0] : data;
    setTableId(tableId);
    setOrderType('DINE_IN');
    router.replace('/menu');
  }

  return (
    <View className="flex-1">
      <CameraView className="flex-1" onBarcodeScanned={scanned ? undefined : handleScan} />
    </View>
  );
}