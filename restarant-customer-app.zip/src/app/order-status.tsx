import { View, Text, ActivityIndicator } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { useQuery } from '@apollo/client/react';
import { TRACK_ORDER_QUERY } from '../lib/graphql';
import { RESTAURANT_SLUG } from '../constants';

const STEPS = ['PENDING', 'CONFIRMED', 'PREPARING', 'READY', 'COMPLETED'];

export default function OrderStatus() {
  const { orderNumber, guestPhone } = useLocalSearchParams<{ orderNumber: string; guestPhone: string }>();

  const { data, loading, error } = useQuery(TRACK_ORDER_QUERY, {
    variables: { restaurantSlug: RESTAURANT_SLUG, orderNumber, guestPhone },
    pollInterval: 5000, // প্রতি ৫ সেকেন্ডে status রিফ্রেশ হবে
  });

  if (loading && !data) return <ActivityIndicator className="flex-1" />;
  if (error || !data) {
    return (
      <View className="flex-1 items-center justify-center p-6">
        <Text>Could not find this order.</Text>
      </View>
    );
  }

  const order = data.trackGuestOrder;
  const currentStepIndex = STEPS.indexOf(order.status);

  return (
    <View className="flex-1 bg-white p-5">
      <Text className="text-xl font-bold">Order #{order.orderNumber}</Text>
      <Text className="mb-5 text-gray-500">Total: ৳{order.total}</Text>

      <View className="mb-6 gap-3">
        {STEPS.map((step, i) => (
          <View key={step} className="flex-row items-center gap-3">
            <View
              className={`h-3 w-3 rounded-full ${i <= currentStepIndex ? 'bg-brand' : 'bg-gray-200'}`}
            />
            <Text className={`${i <= currentStepIndex ? 'font-semibold text-ink' : 'text-gray-400'}`}>
              {step}
            </Text>
          </View>
        ))}
      </View>

      {order.delivery && (
        <View className="rounded-xl bg-gray-50 p-4">
          <Text className="mb-1 font-semibold">Delivery</Text>
          <Text className="text-gray-600">{order.delivery.status}</Text>
          {order.delivery.partnerName && (
            <Text className="mt-1 text-gray-600">Rider: {order.delivery.partnerName}</Text>
          )}
        </View>
      )}

      <View className="mt-5">
        <Text className="mb-2 font-semibold">Items</Text>
        {order.items.map((item: any, i: number) => (
          <Text key={i} className="text-gray-600">
            {item.name} × {item.quantity}
          </Text>
        ))}
      </View>
    </View>
  );
}