import { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useMutation } from '@apollo/client/react';
import { useRouter } from 'expo-router';
import { CREATE_GUEST_ORDER_MUTATION } from '../lib/graphql';
import { useCart } from '../context/CartContext';
import { RESTAURANT_SLUG } from '../constants';

export default function Checkout() {
  const router = useRouter();
  const { items, tableId, orderType, total, clearCart } = useCart();
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');

  const [createOrder, { loading }] = useMutation(CREATE_GUEST_ORDER_MUTATION);

  const needsAddress = orderType === 'DELIVERY';

  async function handleSubmit() {
    if (!guestName.trim() || !guestPhone.trim()) {
      Alert.alert('Missing info', 'Please enter your name and phone number.');
      return;
    }
    if (needsAddress && !deliveryAddress.trim()) {
      Alert.alert('Missing address', 'Please enter your delivery address.');
      return;
    }

    try {
      const { data } = await createOrder({
        variables: {
          input: {
            restaurantSlug: RESTAURANT_SLUG,
            tableId: tableId ?? undefined,
            orderType,
            guestName,
            guestPhone,
            deliveryAddress: needsAddress ? deliveryAddress : undefined,
            items: items.map((l) => ({ menuItemId: l.menuItemId, quantity: l.quantity, note: l.note })),
          },
        },
      });

      const orderNumber = data?.createGuestOrder?.orderNumber;
      clearCart();
      router.replace({ pathname: '/order-status', params: { orderNumber, guestPhone } });
    } catch (err) {
      Alert.alert('Order failed', err instanceof Error ? err.message : 'Please try again.');
    }
  }

  return (
    <View className="flex-1 bg-white p-4">
      <Text className="mb-4 text-lg font-bold">Your details</Text>

      <Text className="mb-1 text-[13px] font-medium text-gray-600">Name</Text>
      <TextInput
        className="mb-3 rounded-lg border border-gray-200 px-3 py-2.5"
        value={guestName}
        onChangeText={setGuestName}
        placeholder="Your name"
      />

      <Text className="mb-1 text-[13px] font-medium text-gray-600">Phone</Text>
      <TextInput
        className="mb-3 rounded-lg border border-gray-200 px-3 py-2.5"
        value={guestPhone}
        onChangeText={setGuestPhone}
        placeholder="01XXXXXXXXX"
        keyboardType="phone-pad"
      />

      {needsAddress && (
        <>
          <Text className="mb-1 text-[13px] font-medium text-gray-600">Delivery address</Text>
          <TextInput
            className="mb-3 rounded-lg border border-gray-200 px-3 py-2.5"
            value={deliveryAddress}
            onChangeText={setDeliveryAddress}
            placeholder="House, road, area"
            multiline
          />
        </>
      )}

      <View className="mt-2 flex-row justify-between border-t border-gray-100 pt-3">
        <Text className="text-base font-semibold">Total (Cash on {needsAddress ? 'delivery' : 'pickup'})</Text>
        <Text className="text-base font-bold">৳{total}</Text>
      </View>

      <TouchableOpacity
        className="mt-6 items-center rounded-xl bg-brand py-3.5 disabled:opacity-50"
        onPress={handleSubmit}
        disabled={loading}
      >
        {loading ? <ActivityIndicator color="white" /> : <Text className="text-[15px] font-bold text-white">Place order</Text>}
      </TouchableOpacity>
    </View>
  );
}