import { View, Text, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useCart } from '../context/CartContext';

export default function Landing() {
  const router = useRouter();
  const { setOrderType } = useCart();

  return (
    <View className="flex-1 items-center justify-center gap-4 p-6 bg-white">
      <Text className="text-2xl font-bold text-ink">Welcome!</Text>
      <Text className="mb-3 text-sm text-gray-500">How would you like to order?</Text>

      <TouchableOpacity
        className="w-full rounded-xl bg-ink py-3.5"
        onPress={() => router.push('/scan')}
      >
        <Text className="text-center text-base font-semibold text-white">Scan QR — I'm at a table</Text>
      </TouchableOpacity>

      <TouchableOpacity
        className="w-full rounded-xl bg-brand py-3.5"
        onPress={() => {
          setOrderType('DELIVERY');
          router.push('/menu');
        }}
      >
        <Text className="text-center text-base font-semibold text-white">Order for delivery/takeaway</Text>
      </TouchableOpacity>
    </View>
  );
}